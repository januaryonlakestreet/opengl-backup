#pragma once

#define RAD2DEG	57.2957795f

//Screen dimensions.
#define SCREEN_WIDTH	800
#define SCREEN_HEIGHT	600
