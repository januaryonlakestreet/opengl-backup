#include "GameScreenLevel1.h"
#include <time.h>
#include <windows.h>
#include <GL\gl.h>
#include <GL\glu.h>
#include "../gl/glut.h"
#include "Constants.h"
#include <vector>
#include "Collision.h"

using namespace::std;

//--------------------------------------------------------------------------------------------------

GameScreenLevel1::GameScreenLevel1() : GameScreen()
{
	srand(time(NULL));

	glEnable(GL_DEPTH_TEST);

	glViewport(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	float aspect = (float)SCREEN_WIDTH / (float)SCREEN_HEIGHT;
	gluPerspective(60.0f,aspect,0.1f,1000.0f);

	glMatrixMode(GL_MODELVIEW);

	glEnable(GL_CULL_FACE);								//Stop calculation of inside faces
	glEnable(GL_DEPTH_TEST);							//Hidden surface removal

	//clear background colour.
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	srand(time(NULL));
	for (int i = 0; i < 20; i++) {
		theTeapots.push_back(new Teapot());
	}
}

//--------------------------------------------------------------------------------------------------

GameScreenLevel1::~GameScreenLevel1()
{	
}

//--------------------------------------------------------------------------------------------------

void GameScreenLevel1::Update(float deltaTime, SDL_Event e)
{
	mCurrentTime += deltaTime;
	for (int i = 0; i < theTeapots.size(); i++) {
		theTeapots[i]->Update();
	}

	// check for collisions
	for (int i = 0; i < theTeapots.size() - 1; i++) {
		for (int j = i + 1; j < theTeapots.size(); j++) {
			Collision::SphereSphereCollision(theTeapots[i]->GetBoundingSphere(), theTeapots[j]->GetBoundingSphere());
			
		}
	}
}

//--------------------------------------------------------------------------------------------------

void GameScreenLevel1::Render()
{
	//Clear the screen.
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
	glLoadIdentity();
	gluLookAt(0.0f, 0.0f, 10.0f,
		      0.0f, 0.0f, 0.0f,
			  0.0f, 1.0f, 0.0f);

	for (int i = 0; i < theTeapots.size(); i++) {
		theTeapots[i]->Render();
	}

	
}

//--------------------------------------------------------------------------------------------------

